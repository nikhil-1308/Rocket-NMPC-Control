function dxdt = OptOriFcn(stage,x,u)
% In a 2D environment with standard XY axis, the rocket is a circular disc
% (20 meters in diameter). The thrust force is applied from the top or
% bottom of the rocket with a gimbal angle.
% x: (1) x position of the center of gravity in m
%    (2) y position of the center of gravity in m
%    (3) theta (tilt with respect to the vertical axis) in radian
%    (4) dx/dt
%    (5) dy/dt
%    (6) dtheta/dt
%
% u: (1) thrust force magnitude in Newton
%    (2) gimbal angle in radian
%
% The continuous-time model is valid only if the rocket is above or at the
% ground (y >= 10).

% mass of rocket (kg)
m = 1;
% length of the rocket from the center of gravity to top/bottom end (m)
L1 = 6;
% length of the rocket from the center of gravity to the center of pressure (m)
Lcp = 7;
% length of the rocket from the center of gravity to the point where the thrust force is applied (m)
Lt = 1;
% gravity (m/s^2)
g = 9.806;
R=2;

Fthrust = u(1);
theta = u(2);
L= 10;
% moment of inertia for a cylinder
I=(1/4)*m*R^2+(1/3)*m*L^2;
% I = 0.5*m*R^2;

% Calculate the thrust force and torque
Fx = Fthrust * sin(theta);
Fy = Fthrust * cos(theta);
Mz = Fthrust * Lt * sin(theta) * cos(theta);

% Calculate the drag and lift forces
% Assume the drag coefficient is 0.1 and the lift coefficient is 0.2
Cd = 0.1e-1;
Cl = 0.1e-2;
v = sqrt(x(4)^2 + x(5)^2);
Fd = 0.5 * Cd * v^2 * cos(x(3)) * m;
Fl = 0.5 * Cl * v^2 * sin(x(3)) * m;
Fx = Fx + Fd * cos(x(3)) + Fl * sin(x(3));
Fy = Fy - Fd * sin(x(3)) + Fl * cos(x(3));

% Calculate the torque due to drag and lift
Md = -Fd * Lcp * sin(x(3)) * cos(x(3));
Ml = Fl * Lcp * cos(x(3)) * sin(x(3));
Mz = Mz + Md + Ml;

% Calculate the force and torque due to gravity
Fg = m * g;
Fx = Fx + Fg * sin(x(3));
Fy = Fy - Fg * cos(x(3));
Mg = -Fg * L1 * sin(x(3)) * cos(x(3));

% treat as "falling" mass
dxdt = [x(4); x(5); 1e-2 - x(6); Fx/m; Fy/m - g; 1e-2 - (Mz + Mg)/I];
% dxdt = [0; 0; 1e-2 - x(6); 0; 0; 1e-2 - (Mz + Mg)/I];
end