function J = RocketLanderCostFcn3D(stage,x,u,dmv,p)
% Rocket lander cost function.

% Copyright 2020 The MathWorks, Inc.

if stage == 1
    J = dmv'*0.1*eye(3)*dmv;
elseif stage == 11
    J = (x-p)'*(x-p);
else
    J = (x-p)'*(x-p) + dmv'*stage*0.1*eye(3)*dmv;
end