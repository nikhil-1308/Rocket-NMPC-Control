function Animation_2D
close all
% Rocket 2D Animation with Displacement, Orientation, and Gimbal Angle Data

% Rocket Parameters
rocketLength = 10; % Length of the rocket
rocketDiameter = 2; % Diameter of the rocket
rocketColor = 'r'; % Color of the rocket
gimbalLength = 2; % Length of the gimbal
gimbalWidth = 0.5; % Width of the gimbal
gimbalColor = 'b'; % Color of the gimbal

load('OUT_2D.mat')

% Import data
displacementData = out.States.signals.values(:,1:2);
orientationData = out.States.signals.values(:,3);
gimbalAngles = out.States.signals.values(:,end);

% Animation Parameters
numFrames = size(displacementData, 1); % Number of animation frames

% Create Figure and Axes
figure;
axis equal;
grid on;
xlim([-35 5]);
ylim([-20 80]);

% Create Rocket and Gimbal Objects
g=hgtransform;
g1=hgtransform;
rocket = rectangle('Parent', g, 'Position', [-rocketDiameter/2, -rocketLength/2, rocketDiameter, rocketLength]',...
    'Curvature', [0.5, 0.5], 'FaceColor', rocketColor);
gimbal = rectangle('Parent', g1, 'Position', [-gimbalWidth/2, -gimbalWidth-12/2, gimbalWidth, gimbalLength],...
    'Curvature', [0.5, 0.5], 'FaceColor', gimbalColor); %gimbalWidth/2

k=rotate(rocket,pi/12,[-rocketDiameter/2, -rocketLength/2]);

% Animation Loop
for frame = 1:numFrames
    % Displacement in X and Y directions
    displacementX = displacementData(frame, 1);
    displacementY = displacementData(frame, 2);

    % Rocket Orientation in X-Y plane
    orientationXY = orientationData(frame);

    % Gimbal Angle in X-Y plane
    gimbalAngleXY = gimbalAngles(frame);

    % Update Rocket Position
    rocketX = displacementX;
    rocketY = displacementY;

    % Update Rocket Position and Orientation
    tform = makehgtform('translate', [rocketX, rocketY, 0],...
                        'yrotate', orientationXY);
    set(rocket, 'Position', [-rocketDiameter/2 + rocketX, -rocketLength/2 + rocketY, rocketDiameter, rocketLength]);
    g.Matrix=makehgtform('axisrotate', [1,1,0], pi/2);

    % Rotate Gimbal in X-Y Plane
    set(gimbal, 'Position', [-gimbalWidth/2 + rocketX, -gimbalWidth-12/2 + rocketY, gimbalWidth, gimbalLength]);
    g1.Matrix=makehgtform('zrotate',deg2rad(gimbalAngleXY));

    % Update Figure
    drawnow;

    % Pause for Animation Speed Control
    pause(0.1);
end
end
