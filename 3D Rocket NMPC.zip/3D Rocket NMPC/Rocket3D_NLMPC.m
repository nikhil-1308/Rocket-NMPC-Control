close all; clear; clc;
% Parameters
g = 9.81;
m = 1;
roh = 1.25;

% * The rocket can have an arbitrary initial position and orientation. 
x0 = [-30;60;30;0;0;0;0;0;0;0];
u0 = [30;0;0];

% In this example, select the prediction horizon |p| and sample time |Ts|
% such that the prediction time is |p*Ts = 10| seconds.
Ts = 0.2;
pPlanner = 50;

% Create a multistage nonlinear MPC controller for the specified prediction
% horizon and sample time.
planner = nlmpcMultistage(pPlanner,10,3);
planner.Ts = Ts;

% Specify prediction model and its analytical Jacobian.
planner.Model.StateFcn = 'RocketStateFcn3D';
% planner.Model.StateJacFcn = 'RocketStateJacobianFcn';

% Specify hard bounds on the two thrusters. You can adjust the maximum
% thrust and observe its impact on the landing strategy chosen by the
% planner. Typical maximum values are between 6 and 10 Newtons. If the
% maximum thrust is too small, you might not be able to land the rocket
% successfully if the initial position is challenging.
planner.MV(1).Min = 0;
planner.MV(1).Max = 30; 
planner.MV(2).Min = -deg2rad(15);
planner.MV(2).Max = deg2rad(15);
planner.MV(3).Min = -deg2rad(15);
planner.MV(3).Max = deg2rad(15);

% To avoid crashing, specify a hard lower bound on the vertical Y position.
planner.States(2).Min = 10;

% There are different factors that you can include in your cost function.
% For example, you can minimize time, fuel consumption, or landing speed.
% For this example, you define a cost function that optimizes fuel
% consumption by minimizing the sum of the thrust values. To improve
% efficiency, you also supply the analytical Jacobian function for the
% cost.
%
% Use the same cost function for all stages. Since MVs are only valid from
% stage 1 to stage |p|, you do not need to define a stage cost for the
% final stage, |p+1|.
for ct=1:pPlanner
    planner.Stages(ct).CostFcn = 'RocketPlannerCostFcn';
%     planner.Stages(ct).CostJacFcn = 'RocketPlannerCostGradientFcn';
end
x0t = [0;10;0;0;0;0;0;0;0;0];
% To ensure a successful landing at the target, specify terminal state for
% the final stage. 
planner.Model.TerminalState = x0t;

% In this example, set the maximum number of iterations to a large value
% to accommodate the large search space and the nonideal default initial
% guess.
planner.Optimization.SolverOptions.MaxIterations = 1000;

% After creating you nonlinear MPC controller, check whether there is any
% problem with your state, cost, and constraint functions, as well as their
% analytical Jacobian functions. To do so, call |validateFcns| functions
% with random initial plant states and inputs.
validateFcns(planner,rand(10,1),rand(3,1));

% Compute the optimal landing path using |nlmpcmove|, which can typically
% take a few seconds, depending on the initial rocket position.
% fprintf('Rocker landing planner running...\n');
tic;
[~,~,info] = nlmpcmove(planner,x0,u0);
t=toc;
fprintf('Calculation Time = %s\n',num2str(t));
fprintf('Objective cost = %s',num2str(info.Cost));
fprintf('ExitFlag = %s',num2str(info.Iterations));
fprintf('Iterations = %s\n',num2str(info.Iterations));

% Extract the optimal trajectory from the |info| structure and plot the
% result.
figure
subplot(2,1,1)
plot3(info.Xopt(:,1),info.Xopt(:,3),info.Xopt(:,2),'*')
title('Optimal XYZ Trajectory')
subplot(2,1,2)
plot(info.Topt,info.MVopt(:,1),info.Topt,info.MVopt(:,2),info.Topt,info.MVopt(:,3))
title('Optimal MV Trajectory')
%%
% Design Lander and Follow the Optimal Path
pLander = 10;
lander = nlmpcMultistage(pLander,10,3);
lander.Ts = Ts;

% For the path-following controller, the lander has the same prediction
% model, thrust bounds, and minimum Y position.
lander.Model.StateFcn = 'RocketStateFcn3D';
% lander.Model.ParameterLength = 3;
% lander.Model.StateJacFcn = 'RocketStateJacobianFcn';
lander.MV(1).Min = 0;
lander.MV(1).Max = 30;
lander.MV(2).Min = -deg2rad(15);
lander.MV(2).Max = deg2rad(15);
lander.MV(3).Min = -deg2rad(15);
lander.MV(3).Max = deg2rad(15);
lander.States(2).Min = 10;

% The cost function for the lander is different from that of the planner.
for ct=1:pLander+1
    lander.Stages(ct).CostFcn = 'RocketLanderCostFcn3D';
    lander.Stages(ct).ParameterLength = 10;
end

% The Inequality function
% for ct=2:pLander+1
%     nlobj.Stages(ct).IneqConFcn = "RocketLanderIneqConFcn";
% end

% State constraints
% lander.States(9).Min = -1e-3;
% lander.States(9).Max = 1e-3;
% lander.States(10).Min = -1e-3;
% lander.States(10).Max = 1e-3;

% Since changes in control actions are represented by |MVRate|, you must
lander.UseMVRate = true;
% Validate the controller design.
simdata = getSimulationData(lander,'TerminalState');
% simdata.StateFcnParameter = [roh;g;m];
% simdata.StageParameter = repmat(x0t,pLander+1,1);
% simdata.TerminalState = x0t;
validateFcns(lander,rand(10,1),rand(3,1),simdata);

% Extract reference signal as column vector.
references = reshape(info.Xopt',(pPlanner+1)*10,1);
