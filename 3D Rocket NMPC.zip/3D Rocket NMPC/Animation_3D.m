function Animation_3D
% Rocket Animation with Displacement and Orientation Data

% Rocket Parameters
rocketLength = 10; % Length of the rocket
rocketDiameter = 2; % Diameter of the rocket
rocketColor = 'r'; % Color of the rocket
gimbalLength = 2; % Length of the gimbal
gimbalWidth = 0.5; % Width of the gimbal
gimbalColor = 'b'; % Color of the gimbal

load('OUT.mat')

% Import data
displacementData = out.States.signals.values(:,1:3);
orientationData = out.States.signals.values(:,4:5);
gimbalAngles = out.States.signals.values(:,end-1:end);

% Animation Parameters
numFrames = size(displacementData, 1); % Number of animation frames

% Create Figure and Axes
figure;
axis equal;
grid on;
view(3);
xlim([-20 20]);
ylim([-20 20]);
zlim([-20 20]);

% Create Rocket and Gimbal Objects
rocket = rectangle('Position', [-rocketDiameter/2, -rocketDiameter/2, rocketLength, rocketDiameter],...
    'Curvature', [0.5, 0.5], 'FaceColor', rocketColor);
gimbal = rectangle('Position', [-gimbalWidth/2, -gimbalWidth/2, gimbalLength, gimbalWidth],...
    'Curvature', [0.5, 0.5], 'FaceColor', gimbalColor);

% Animation Loop
for frame = 1:numFrames
    % Displacement in X, Y, Z directions
    displacementX = displacementData(frame, 1);
    displacementY = displacementData(frame, 2);
    displacementZ = displacementData(frame, 3);

    % Rocket Orientation in X-Y and Y-Z planes
    orientationXY = orientationData(frame, 1);
    orientationYZ = orientationData(frame, 2);

    % Gimbal Angles in X-Y and Y-Z planes
    gimbalAngleXY = gimbalAngles(frame, 1);
    gimbalAngleYZ = gimbalAngles(frame, 2);

    % Update Rocket Position
    rocketX = displacementX;
    rocketY = displacementY;
    rocketZ = displacementZ + displacementY; % Adding 'y' as altitude

    % Update Rocket Position and Orientation
    tform = makehgtform('translate', [rocketX, rocketY, rocketZ],...
                        'zrotate', deg2rad(orientationXY));
    set(rocket, 'XData', rocketX + [-rocketLength/2 rocketLength/2]);
    set(rocket, 'YData', rocketY + [-rocketDiameter/2 rocketDiameter/2]);
    set(rocket, 'ZData', rocketZ + [0 0]);

    % Rotate Gimbal in X-Y Plane
    tformXY = makehgtform('zrotate', deg2rad(gimbalAngleXY));
    set(gimbalXY, 'Matrix', tformXY);

    % Rotate Gimbal in Y-Z Plane
    tformYZ = makehgtform('xrotate', deg2rad(gimbalAngleYZ));
    set(gimbalYZ, 'Matrix', tformYZ);

    % Update Figure
    drawnow;

    % Pause for Animation Speed Control
    pause(0.1);
end

end