function plot_3D
load OUT.mat
load plOUT.mat

figure
plot3(info.Xopt(:,1),info.Xopt(:,3),info.Xopt(:,2),'*',...
    out.States.signals.values(:,1),...
    out.States.signals.values(:,3),out.States.signals.values(:,2),'-o')
legend('Planned Trajectory','Simulated Trajectory')
title('Rocket Trajectory')
end