function ref = RocketLanderReferenceSignal_01(k, planned, pLander)
% Rocket lander reference signal generator.

% Copyright 2020 The MathWorks, Inc.

% k start from 1
last = numel(planned);
expectStartIdx = (k-1)*7+1;
expectEndIdx = (k+pLander)*7;
len = (pLander+1)*7;
ref = zeros(len,1);
if expectEndIdx<=last
    for ct=1:len
        ref(ct) = planned(expectStartIdx+ct-1);
    end
elseif expectStartIdx<=last
    copied = last - expectStartIdx + 1;
    for ct=1:copied
        ref(ct) = planned(expectStartIdx+ct-1);
    end
    missed = 7*(pLander+1)-copied;
    appended = repmat(planned(end-6:end),missed/7,1);
    ref(copied+1:end) = appended;
else
    for ct=0:7:len-1
        ref(ct+1:ct+7) = planned(end-6:end);
    end
end

